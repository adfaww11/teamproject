package com.businessman.controller;

import java.security.Principal;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.businessman.domain.MemberVO;
import com.businessman.service.MemberService;

import lombok.AllArgsConstructor;

@RequestMapping("/*")
@Controller
@AllArgsConstructor
public class MemberController {
	private MemberService service;
	
	//로그인창
	@GetMapping("/bmlogin")
	public void gologin(String error, Model model) {
		if(error!=null) {
			model.addAttribute("error", "로그인에 실패했습니다. 다시 시도해주세요.");
		}
	}
	//회원가입창
	@GetMapping("/join")
	public void gojoin() {}
	
	//마이페이지
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mypage")
	public void gomypage(Principal principal, Model model, String nick) {
		nick = principal.getName();
		model.addAttribute("memInfo", service.getMemInfo(nick));
		model.addAttribute("memBoard", service.getMemBoard(nick));
	}
	
	//회원정보 수정창
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mypageUpdate")
	public void infoUpdate(Principal principal, Model model, String nick) {
		nick = principal.getName();
		model.addAttribute("memInfo", service.getMemInfo(nick));
	}
	
	//회원정보 업데이트
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/mypageUpdate")
	public String updateInfo(MemberVO member) {
		BCryptPasswordEncoder scpwd = new BCryptPasswordEncoder();
        String password = scpwd.encode(member.getPassword());
        member.setPassword(password);
		
        service.updateInfo(member);
        
		return "redirect:/bmlogout";
	}
	
	//회원가입
	@PostMapping("/join")
	public String getjoin(MemberVO member) {
		BCryptPasswordEncoder scpwd = new BCryptPasswordEncoder();
        String password = scpwd.encode(member.getPassword());
        member.setPassword(password);
		
		service.getjoin(member);
		return "redirect:/bmlogin";
	}
	
	//닉네임 체크
    @ResponseBody
    @GetMapping("/nickCheck")
    public int nickCheck(@RequestParam("nick") String nick){
        int cnt = service.nickCheck(nick);
        return cnt;
    }
	
   //이메일 체크
    @ResponseBody
    @GetMapping("/emailCheck")
    public int emailCheck(@RequestParam("email") String email){
        int cnt = service.emailCheck(email);
        return cnt;
    }
    
    //로그아웃처리
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/bmlogout") 
    public void logoutGET() {}
	 
    @PostMapping("/bmlogout") 
    public void logoutPost() {}
	 
}
