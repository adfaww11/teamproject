package com.businessman.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.businessman.domain.Criteria;
import com.businessman.service.MainService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;


@RequestMapping("/main/*")
@Controller
@Log4j
@AllArgsConstructor
public class MainController {
	private MainService service;

	@GetMapping("/list")
	public void list(Model model) {
		log.info("list" +  service.getList());
		model.addAttribute("list", service.getList());
	}
	
	@GetMapping("/category")
    public void category(@RequestParam("category") String category, @ModelAttribute("cri") Criteria cri, Model model) {
        log.info("list" +  service.listbrand(category));
        model.addAttribute("list", service.listbrand(category));
    }
	

	 @GetMapping("/info") 
	 public void info(@RequestParam("bname") String bname, Model model) { 
		 log.info("info" + service.infocost(bname)); 
		 model.addAttribute("info", service.infocost(bname)); 
		 log.info("brand" + service.infobrand(bname)); 
		 model.addAttribute("brand", service.infobrand(bname)); 
	}

	
}
