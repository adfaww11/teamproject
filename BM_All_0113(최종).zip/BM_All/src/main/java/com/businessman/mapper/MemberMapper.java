package com.businessman.mapper;

import java.util.List;

import com.businessman.domain.BoardVO;
import com.businessman.domain.MemberVO;

public interface MemberMapper {
	public MemberVO read(String nick);
	public void joinmember(MemberVO member);
	public void insertauth(MemberVO member);
	public int nickCheck(String nick);
	public int emailCheck(String email);
	public MemberVO getMemInfo(String nick);
	public List<BoardVO> getMemBoard(String nick);
	public void updateMem(MemberVO member);
}
