package com.businessman.domain;

import lombok.Data;

@Data
public class CategoryVO {
	private String bname;
	private String category;
	private String blogo;
	private String type;
	private long store;
}
