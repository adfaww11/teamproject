package com.businessman.domain;

import lombok.Data;

@Data
public class AuthVO {
	 private String nick;
	 private String auth;
}
