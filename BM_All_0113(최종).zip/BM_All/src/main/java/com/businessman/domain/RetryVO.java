package com.businessman.domain;

import java.util.Date;

import lombok.Data;

@Data
public class RetryVO {
	private int rno;
	private int bno;
	private String reply;
	private Date repdate;
	private String nick;
}
