package com.businessman.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ListVO {
	private long bno;
	private String title;
	private String nick;
	private Date regdate;

}