package com.businessman.service;

import java.util.List;

import com.businessman.domain.BoardVO;
import com.businessman.domain.MemberVO;

public interface MemberService {
	public MemberVO read(String nick);
	public void getjoin(MemberVO member);
	public int nickCheck(String nick);
	public int emailCheck(String email);
	public MemberVO getMemInfo(String nick);
	public List<BoardVO> getMemBoard(String nick);
	public void updateInfo(MemberVO member);
}
