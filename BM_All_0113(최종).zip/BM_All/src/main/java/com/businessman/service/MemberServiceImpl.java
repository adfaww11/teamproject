package com.businessman.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.businessman.domain.BoardVO;
import com.businessman.domain.MemberVO;
import com.businessman.mapper.MemberMapper;

import lombok.Setter;

@Service
public class MemberServiceImpl implements MemberService {

	@Setter(onMethod_ = @Autowired)
	private MemberMapper mapper;

	//로그인
	@Override
	public MemberVO read(String nick) {
		return mapper.read(nick);
	}

	//회원가입
	@Override
	@Transactional
	public void getjoin(MemberVO member) {
		mapper.joinmember(member);
		mapper.insertauth(member);
	}

	//닉네임체크
	@Override
	public int nickCheck(String nick) {
		int cnt = mapper.nickCheck(nick);
		return cnt;
	}

	//이메일체크
	@Override
	public int emailCheck(String email) {
		int cnt = mapper.emailCheck(email);
		return cnt;
	}

	//회원정보가져오기(마이페이지)
	@Override
	public MemberVO getMemInfo(String nick) {
		return mapper.getMemInfo(nick);
	}

	//쓴글가져오기(마이페이지)
	@Override
	public List<BoardVO> getMemBoard(String nick) {
		return mapper.getMemBoard(nick);
	}

	//회원정보 수정하기
	@Override
	public void updateInfo(MemberVO member) {
		mapper.updateMem(member);
		
	}


}
